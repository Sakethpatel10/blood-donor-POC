package com.example.BloodDonor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BloodDonorPocApplicationTests {

	@Test
	void contextLoads() {
	}

}
