package com.example.BloodDonor.Controller;

import com.example.BloodDonor.Entity.Address;
import com.example.BloodDonor.Service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.service.annotation.GetExchange;

import java.util.List;
import java.util.Set;

@RestController
public class AddressController {
    @Autowired
    private AddressService addressService;

    @GetMapping("/getCountry")
    public ResponseEntity<List<String>> getAllCountries(){
        return new ResponseEntity<>(addressService.getAllCountries(),HttpStatus.OK);
    }
    @PostMapping("/addAddress/")
    public ResponseEntity<Address> addAddress(@RequestBody Address address){
        return  new ResponseEntity<>(addressService.addAddressDetails(address),HttpStatus.CREATED);
    }
    @GetMapping("/getState/{Country}")
    public ResponseEntity<List<String>> getAllStates(@PathVariable String Country){
        return new ResponseEntity<>(addressService.getAllStates(Country),HttpStatus.OK);
    }
    @GetMapping("/getdistrict/{State}")
    public ResponseEntity<List<String>> getAllDistricts(@PathVariable String State){
        return new ResponseEntity<>(addressService.getAllDistrict(State),HttpStatus.OK);
    }
    @GetMapping("/getCity/{District}")
    public ResponseEntity<List<String>> getAllCity(@PathVariable String District){
        return new ResponseEntity<>(addressService.getAllCities(District),HttpStatus.OK);
    }
    @GetMapping("getDistrictNew/{Country}/{State}")
    public ResponseEntity<List<String>> getAllDistrictsNew(@PathVariable String Country,@PathVariable String State){
        return new ResponseEntity<>(addressService.getAllDistrictsByContAndSta(Country,State),HttpStatus.OK);
    }
   @GetMapping("/getAddressId/{city}")
   public int  getAddressId(@PathVariable String city ){
        return addressService.getAddressId(city);
    }
    @GetMapping("/getcity/{country}/{state}/{district}")
    public ResponseEntity<List<String>> getCititesNewMethod(@PathVariable String country,@PathVariable String state,@PathVariable String district)
    {
        return new ResponseEntity<>(addressService.getcities(country,state,district),HttpStatus.OK);
    }
}
