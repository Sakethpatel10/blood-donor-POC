package com.example.BloodDonor.Service;

import com.example.BloodDonor.Entity.Donor;

import java.util.List;

public interface DonorService {
List<Donor> finddonorbyId(int addressid);
List<Donor> finddonorbyblood(int bloodid);
List<Donor> findDonorDetails(int addressid,int bloodid);
}
