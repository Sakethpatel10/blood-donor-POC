package com.example.BloodDonor.ServiceImplementation;

import com.example.BloodDonor.Entity.BloodGroup;
import com.example.BloodDonor.Repository.BloodGroupRepository;
import com.example.BloodDonor.Service.BloodGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BloodGroupServiceImplementation implements BloodGroupService {
    @Autowired
    private BloodGroupRepository bloodGroupRepository;
    @Override
    public BloodGroup addBloodGroup(BloodGroup bloodGroup) {
        return bloodGroupRepository.save(bloodGroup);
    }

    @Override
    public List<String> getAllBloodGroup() {
        List<String> bloodgroups=new ArrayList<>();
        List<BloodGroup> bloodGroupList=bloodGroupRepository.findAll();
        for(BloodGroup bg:bloodGroupList){
            bloodgroups.add(bg.getBloodgroup());
        }
        return bloodgroups;
    }
}
