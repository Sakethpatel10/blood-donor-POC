package com.example.BloodDonor.ServiceImplementation;

import com.example.BloodDonor.Service.LoginService;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceImplementation implements LoginService {
}
