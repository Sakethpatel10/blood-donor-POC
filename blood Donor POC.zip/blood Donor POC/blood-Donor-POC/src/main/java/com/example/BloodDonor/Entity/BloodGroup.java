package com.example.BloodDonor.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name="blood_group")
public class BloodGroup {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int bloodid;
    private String bloodgroup;
}
