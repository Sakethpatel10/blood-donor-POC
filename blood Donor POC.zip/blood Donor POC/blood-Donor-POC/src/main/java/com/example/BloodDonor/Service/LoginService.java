package com.example.BloodDonor.Service;

public interface LoginService {
}
