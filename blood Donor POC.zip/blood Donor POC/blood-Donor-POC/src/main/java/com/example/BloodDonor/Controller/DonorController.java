package com.example.BloodDonor.Controller;

import com.example.BloodDonor.Entity.Donor;
import com.example.BloodDonor.Service.DonorService;
import jakarta.persistence.GeneratedValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class DonorController {
    @Autowired
    private DonorService donorService;
    @GetMapping("/getDonors/{addressid}")
    public ResponseEntity<List<Donor>> getbyAddressId(@PathVariable int addressid)
    {
        return new ResponseEntity<List<Donor>>(donorService.finddonorbyId(addressid),HttpStatus.OK);
    }
    @GetMapping("/getDonorsByBlood/{bloodid}")
    public ResponseEntity<List<Donor>> getbyBloodId(@PathVariable int bloodid){
        return new ResponseEntity<>(donorService.finddonorbyblood(bloodid),HttpStatus.OK);
    }
    @GetMapping("/getDonorsData/{addressid}/{bloodid}")
    public ResponseEntity<List<Donor>> getDonordetails(@PathVariable int addressid,@PathVariable int bloodid)
    {
        return new ResponseEntity<>(donorService.findDonorDetails(addressid,bloodid),HttpStatus.OK);
    }
}
