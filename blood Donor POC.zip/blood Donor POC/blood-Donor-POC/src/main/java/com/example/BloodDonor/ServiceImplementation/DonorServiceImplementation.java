package com.example.BloodDonor.ServiceImplementation;

import com.example.BloodDonor.Entity.Donor;
import com.example.BloodDonor.Repository.DonorRepository;
import com.example.BloodDonor.Service.DonorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DonorServiceImplementation implements DonorService {
    @Autowired
    private DonorRepository donorRepository;

    @Override
    public List<Donor> finddonorbyId(int addressid) {
        return donorRepository.findByAddress(addressid);

    }

    @Override
    public List<Donor> finddonorbyblood(int bloodid) {
        return donorRepository.findByBloodGroup(bloodid);
    }
    public List<Donor> findDonorDetails(int addressid,int bloodid){
        return donorRepository.findByAddressAndBloodGroup(addressid,bloodid);
    }
}
