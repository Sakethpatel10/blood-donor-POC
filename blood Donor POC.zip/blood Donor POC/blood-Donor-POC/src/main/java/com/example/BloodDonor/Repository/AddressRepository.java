package com.example.BloodDonor.Repository;

import com.example.BloodDonor.Entity.Address;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AddressRepository extends JpaRepository<Address,Integer> {
    List<Address> findByCountry(String country);
    List<Address> findByState(String state);
    List<Address> findByDistrict(String district);
    List<Address> findByCountryAndState(String country,String state);

    List<Address> findByCountryAndStateAndDistrict(String country,String state,String district);
    Address findByCity(String city);
}
