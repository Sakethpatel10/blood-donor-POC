package com.example.BloodDonor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BloodDonorPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(BloodDonorPocApplication.class, args);
	}

}
