package com.example.BloodDonor.ServiceImplementation;

import com.example.BloodDonor.Entity.Address;
import com.example.BloodDonor.Repository.AddressRepository;
import com.example.BloodDonor.Service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class AddressServiceImplementation implements AddressService {
    @Autowired
    private AddressRepository addressRepository;
    @Override
    public List<String> getAllCountries() {
        List<Address> addressList=addressRepository.findAll();
        Set<String> country=new HashSet<>();
        for(Address ad:addressList){
            country.add(ad.getCountry());
        }
        List<String> list= country.stream().toList();
        return list;
    }

    @Override
    public Address addAddressDetails(Address address) {
        return addressRepository.save(address);
    }

    @Override
    public List<String> getAllStates(String country) {
        List<Address> statesList=addressRepository.findByCountry(country);
        Set<String> stateset=new HashSet<>();
        for(Address ad:statesList){
            stateset.add(ad.getState());
        }
        List<String> states= stateset.stream().toList();
        return states;
    }

    @Override
    public List<String> getAllDistrict(String state) {
        List<Address> districtlist=addressRepository.findByState(state);
        Set<String> set=new HashSet<>();
        for(Address ad:districtlist){
            set.add(ad.getDistrict());
        }
        List<String> districts=set.stream().toList();
        return districts;
    }

    @Override
    public List<String> getAllDistrictsByContAndSta(String country, String state) {
        List<Address> districtlist=addressRepository.findByCountryAndState(country,state);
        Set<String> set=new HashSet<>();
        for(Address ad:districtlist){
            set.add(ad.getDistrict());
        }
        List<String> districts=set.stream().toList();
        return districts;
    }

    @Override

    public List<String> getAllCities(String district) {
        List<Address> Citieslist=addressRepository.findByDistrict(district);
        Set<String> set=new HashSet<>();
        for(Address ad:Citieslist){
            set.add(ad.getCity());
        }
        List<String> cities=set.stream().toList();
        return cities;
    }

    @Override
    public List<String> getcities(String country, String state, String district) {
        List<Address> Citieslist=addressRepository.findByCountryAndStateAndDistrict(country,state,district);
        Set<String> set=new HashSet<>();
        for(Address ad:Citieslist){
            set.add(ad.getCity());
        }
        List<String> cities=set.stream().toList();
        return cities;
    }

    @Override
    public int getAddressId( String city) {
        Address address=addressRepository.findByCity(city);
        System.out.println(address.getAddressid());
        return address.getAddressid();

    }


}
