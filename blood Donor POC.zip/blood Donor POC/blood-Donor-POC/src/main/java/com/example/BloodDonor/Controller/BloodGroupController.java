package com.example.BloodDonor.Controller;


import com.example.BloodDonor.Entity.BloodGroup;
import com.example.BloodDonor.Service.BloodGroupService;
import com.example.BloodDonor.ServiceImplementation.BloodGroupServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class BloodGroupController {
    @Autowired
    private BloodGroupServiceImplementation bloodGroupServiceImplementation;
    @PostMapping("/addBloodGroup")
    public ResponseEntity<BloodGroup> addBloodgroups(@RequestBody BloodGroup bloodGroup)
    {
        return  new ResponseEntity<>(bloodGroupServiceImplementation.addBloodGroup(bloodGroup), HttpStatus.OK);
    }
    @GetMapping("/getAllBloodGroups")
    public ResponseEntity<List<String>> getBloodGroups(){
        return new ResponseEntity<>(bloodGroupServiceImplementation.getAllBloodGroup(),HttpStatus.OK);
    }
}
